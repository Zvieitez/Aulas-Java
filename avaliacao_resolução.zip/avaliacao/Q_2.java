package avaliacao;

import java.util.Scanner;

public class Q_2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Informe o primeiro numero");
        int a = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Informe o segundo numero");
        int b = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Informe o terceiro numero");
        int c = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Informe o quarto numero");
        int d = scanner.nextInt();
        scanner.nextLine();

        int diferenca = (a * b) - (c * d);

        System.out.println("Valor: " + diferenca);
    }
}
