package avaliacao;

import java.util.Scanner;

public class Q_3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Informe o nome");
        String nome = scanner.nextLine();

        System.out.println("Informe as horas trabalhadas");
        int horasTrabalhadas = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Informe o valor da hora");
        double valorHoras = scanner.nextDouble();
        scanner.nextLine();

        double totalHorasTrabalhadas = valorHoras * horasTrabalhadas;

        System.out.println("o Total de horas do trabalhador, " + nome + "foi " + totalHorasTrabalhadas);
    }
}
