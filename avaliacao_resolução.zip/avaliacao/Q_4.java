package avaliacao;

import java.util.Scanner;

public class Q_4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Informe o primeiro numero");
        int num_1 = scanner.nextInt();
        scanner.nextLine();

        if(num_1 < 0){
            System.out.println("Numero negativo");
        }else {
            System.out.println("Numero positivo");
        }
    }
}
