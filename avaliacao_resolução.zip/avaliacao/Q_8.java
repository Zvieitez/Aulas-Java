package avaliacao;

import java.util.Scanner;

public class Q_8 {
    public static void main(String[] args) {
        String[] arrProduto = new String[10];
        int[] arrEstoque = new int[10];

        System.out.println("(1) Cadastro de produtos");
        System.out.println("(2) venda de produtos");
        System.out.println("(3) Imprimir relatorio");
        System.out.println("(4) Sair");

        Scanner scanner = new Scanner(System.in);
        System.out.println("Selecione uma opcao de 1 a 4");
        int opcapEscolhida = Integer.parseInt(scanner.nextLine());

        int indiceProduto = 0;

        while(opcapEscolhida <= 3) {
            if(opcapEscolhida == 1){
                System.out.println("Informe o nome do Produto");
                String produto = scanner.nextLine();
                arrProduto[indiceProduto] = produto;

                System.out.println("Informe o estoque do produto");
                int estoque = scanner.nextInt();
                scanner.nextLine();
                arrEstoque[indiceProduto] = estoque;
                indiceProduto++;
            }

            if(opcapEscolhida == 2){
                System.out.println("Adicione um produto ao carrinho, informe seu codigo");
                System.out.println("Codigos disponiveis até o numero - "+ (indiceProduto - 1));
                int codigo = scanner.nextInt();
                scanner.nextLine();

                System.out.println("Quantos produtos?");
                int qtdProdutos = scanner.nextInt();
                scanner.nextLine();

                int saldo = arrEstoque[codigo] - qtdProdutos;

                if(saldo < 0){
                    System.out.println("Não há estoque disponível para esse produto.");
                }else {
                    arrEstoque[codigo] = saldo;
                }
            }

            if(opcapEscolhida == 3){
                int maisVendido = 0;
                String produtoMaisVendido = "";
                for (int i = 0; i < indiceProduto; i++) {
                    System.out.println(arrProduto[i]);
                    System.out.println(arrEstoque[i]);
                    if(arrEstoque[i] > maisVendido){
                        produtoMaisVendido = arrProduto[i];
                    }
                    System.out.println("==============================================");
                }
                System.out.println("Produto mais vendido: " + produtoMaisVendido);
                System.out.println("==============================================");
            }

            System.out.println("(1) Cadastro de produtos");
            System.out.println("(2) venda de produtos");
            System.out.println("(3) Imprimir relatorio");
            System.out.println("(4) Sair");

            System.out.println("Selecione uma opcao de 1 a 4");
            opcapEscolhida = Integer.parseInt(scanner.nextLine());
        }
    }
}
