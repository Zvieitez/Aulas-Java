package avaliacao;

public class Q_10 {
    public static void main(String[] args) {
        int[] arrNumeros = {43,78,45,22,44,56,77, 666, 2, 5};

        int maiorValor = 0;
        for (int i = 0; i < arrNumeros.length; i++) {
            if( arrNumeros[i] > maiorValor){
                maiorValor = arrNumeros[i];
            }
            System.out.println(arrNumeros[i]);
        }
        System.out.println("Maior valor e: " + maiorValor);
    }
}
