package avaliacao;

import java.util.Scanner;

public class Q_7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < 4; i++) {
            int caso = i+1;
            System.out.println("Informe a " + caso + " altura");
            double altura = scanner.nextDouble();
            scanner.nextLine();

            System.out.println("Informe a " + caso + " peso");
            double peso = scanner.nextDouble();
            scanner.nextLine();

            double imc = (peso / (altura * altura));
            System.out.println("IMC do " + caso + " caso");
            System.out.println("Classificacao:");

            if (imc >= 18.5 && imc <= 24.9){
                System.out.println("Peso Normal");
            }else if (imc >= 25 && imc <= 29.9){
                System.out.println("Acima do peso");
            }else if (imc >= 30 && imc <= 34.9){
                System.out.println("Obeso 1");
            }else if (imc >= 35 && imc <= 39.9){
                System.out.println("Obeso 2");
            }else if (imc >= 40){
                System.out.println("Obeso demais, se cuide");
            }
        }
    }
}
