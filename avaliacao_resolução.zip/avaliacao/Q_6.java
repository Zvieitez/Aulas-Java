package avaliacao;

import java.util.Scanner;

public class Q_6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String senhaSecreta = "Moderna@2022";

        boolean senhaOK = false;
        while(!senhaOK){
            System.out.println("Informe a senha");
            String senha = scanner.nextLine();
            if(senha.equals(senhaSecreta)){
                senhaOK = true;
            }else {
                System.out.println("Senha incorreta, tente novamente");
            }
        }
        System.out.println("Bem vindo ao sistema");
    }
}
