package avaliacao;

import java.util.Scanner;

public class Q_9 {
    public static void main(String[] args) {
        int soma = 0;
        Scanner scanner = new Scanner(System.in);
        int numero = 0;
        while(true){
            System.out.println("Informe o numero");
            numero = scanner.nextInt();
            scanner.nextLine();
            if(numero < 0){
                break;
            }
            soma  = soma + numero;
        }
        System.out.println("Soma dos numero : " + soma);
    }
}
