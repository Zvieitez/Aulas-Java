package avaliacao;

import java.util.Scanner;

public class Q_5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Informe o primeiro numero");
        int num_1 = scanner.nextInt();
        scanner.nextLine();

        if(num_1 % 2 > 0){
            System.out.println("Numero impar");
        }else {
            System.out.println("Numero par");
        }
    }
}
